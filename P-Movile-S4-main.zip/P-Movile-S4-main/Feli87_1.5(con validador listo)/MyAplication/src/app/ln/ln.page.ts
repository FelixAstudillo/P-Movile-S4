import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ln',
  templateUrl: './ln.page.html',
  styleUrls: ['./ln.page.scss'],
})
export class LNPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
