import { Component, OnInit } from '@angular/core';
import { FirestoreService } from '../services/firestore.service';

@Component({
  selector: 'app-re',
  templateUrl: './re.page.html',
  styleUrls: ['./re.page.scss'],
  standalone: false
})
export class RePage implements OnInit {
  nombre: string = '';
  email: string = '';
  password: string = '';        // Nueva propiedad para la contraseña
  confirmacion: string = '';    // Nueva propiedad para confirmar la contraseña
  user: any[] = [];

  constructor(private firestoreService: FirestoreService) {}

  ngOnInit() {
    // Cargar user desde Firestore
    this.firestoreService.getDocuments('users').subscribe(data => {
      this.user = data;
    });
  }

  // Método para agregar datos a Firestore
  async saveUser() {
    if (this.nombre === '' || this.email === '' || this.password === '' || this.confirmacion === '') {
      alert('Por favor completa todos los campos.');
      return;
    }

    if (this.password !== this.confirmacion) {
      alert('Las contraseñas no coinciden.');
      return;
    }

    const data = {
      nombre: this.nombre,
      email: this.email,
      password: this.password,  // Almacenar la contraseña
      fechaRegistro: new Date()
    };

    try {
      // Guardar los datos en Firestore
      await this.firestoreService.addDocument('users', data);
      alert('Usuario registrado exitosamente.');
      this.nombre = '';
      this.email = '';
      this.password = '';
      this.confirmacion = '';
    } catch (error) {
      console.error('Error al guardar el usuario:', error);
      alert('Hubo un error al registrar el usuario.');
    }
  }
}
