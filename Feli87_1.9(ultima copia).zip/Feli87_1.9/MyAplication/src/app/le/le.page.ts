import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ToastController } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth/auth.service';  // Asegúrate de tener este servicio correctamente importado.

@Component({
  selector: 'app-le',
  templateUrl: './le.page.html',
  styleUrls: ['./le.page.scss'],
  standalone: false
})
export class LePage implements OnInit {

  emailForm: FormGroup;
  email: string = "";
  password: string = "";

  constructor(
    public mensaje: ToastController,
    public alerta: AlertController,
    private router: Router,
    private fb: FormBuilder,
    private authService: AuthService // Inyectamos el servicio de autenticación
  ) {
    this.emailForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(18)]], // Corregimos la validación de la contraseña
    });
  }

  // Mostrar mensaje de error si los campos están vacíos
  async MensajeError() {
    const alert = await this.alerta.create({
      header: '¡ALTO AHÍ!',
      message: 'Ningún campo de texto debe estar vacío',
      buttons: ['GRACIAS']
    });
    await alert.present();
  }

  // Mostrar mensaje de éxito si el login es exitoso
  async MensajeCorrecto() {
    const toast = await this.mensaje.create({
      message: 'Inicio de sesión exitoso',
      duration: 2000
    });
    toast.present();
  }

  // Función de submit del formulario (validación)
  onSubmit() {
    if (this.emailForm.invalid) {
      this.MensajeError(); // Mostramos error si el formulario no es válido
      return;
    }
    console.log('Formulario enviado:', this.emailForm.value);
  }

  // Función para ingresar (login)
  ingresar() {
    // Verificamos si los campos están vacíos
    if (this.emailForm.invalid) {
      this.MensajeError();
      return;
    }

    const email = this.emailForm.get('email')?.value;
    const password = this.emailForm.get('password')?.value;

    // Usamos el servicio de autenticación para iniciar sesión
    this.authService.login(email, password).then(async (result) => {
      if (result) {
        await this.MensajeCorrecto();
        this.router.navigate(['/home']); // Redirigir al home
      } else {
        this.MensajeError(); // Si las credenciales son incorrectas, mostramos error
      }
    }).catch(async (error) => {
      console.error('Error en el login:', error);
      await this.MensajeError(); // Mostramos un mensaje de error si hay algún problema
    });
  }

  ngOnInit() {}
}
