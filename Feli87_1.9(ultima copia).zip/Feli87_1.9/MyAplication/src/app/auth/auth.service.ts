import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore, DocumentSnapshot } from '@angular/fire/compat/firestore';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private afAuth: AngularFireAuth, private firestore: AngularFirestore) {}

  // Login
  async login(email: string, password: string): Promise<any> {
    try {
      // Inicia sesión con las credenciales proporcionadas
      const userCredential = await this.afAuth.signInWithEmailAndPassword(email, password);
      const user = userCredential.user;

      if (user) {
        // Obtener los datos adicionales del usuario desde Firestore usando su UID
        const userDataSnapshot = await this.firestore.collection('users').doc(user.uid).get().toPromise();

        // Verificar si el documento existe y si no es undefined
        if (userDataSnapshot && userDataSnapshot.exists) {
          // Si el documento existe, devolver los datos del usuario
          const userData = userDataSnapshot.data();  // Obtiene los datos del documento
          return { user, userData };
        } else {
          console.log('No se encontraron datos del usuario en Firestore');
          return null;
        }
      }
      return null; // Si el usuario no existe o no es válido
    } catch (error) {
      console.error('Error en el inicio de sesión:', error);
      throw error; // Lanza el error para que lo maneje el componente
    }
  }
}
