import { TestBed } from '@angular/core/testing';
import { FirestoreService } from './firestore.service';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { of } from 'rxjs';

// Mock de AngularFirestore
class AngularFirestoreMock {
  collection(collectionName: string) {
    return {
      add: (data: any) => Promise.resolve({ id: '123', ...data }), // Simula agregar un documento
      valueChanges: () => of([{ nombre: 'John Doe', email: 'john@example.com', fechaRegistro: new Date() }]), // Simula la lectura de documentos
      doc: (id: string) => ({
        delete: () => Promise.resolve() // Simula eliminar un documento
      })
    };
  }
}

describe('FirestoreService', () => {
  let service: FirestoreService;
  let firestoreMock: AngularFirestoreMock;

  beforeEach(() => {
    firestoreMock = new AngularFirestoreMock(); // Crear la instancia del mock
    TestBed.configureTestingModule({
      providers: [
        FirestoreService,
        { provide: AngularFirestore, useValue: firestoreMock } // Usar el mock en lugar del servicio real
      ]
    });
    service = TestBed.inject(FirestoreService); // Inyectar el servicio FirestoreService
  });

  it('should be created', () => {
    expect(service).toBeTruthy(); // Verifica que el servicio sea creado correctamente
  });

  it('should add a user document', async () => {
    const data = { nombre: 'Jane Doe', email: 'jane@example.com' };
    const response = await service.addDocument('usuarios', data);

    expect(response).toEqual({ id: '123', ...data }); // Verifica que el documento se agregue correctamente
  });

  it('should get user documents', (done) => {
    service.getDocuments('usuarios').subscribe((data) => {
      expect(data.length).toBeGreaterThan(0); // Verifica que haya documentos obtenidos
      expect(data[0].nombre).toBe('John Doe'); // Verifica el contenido de los documentos
      done();
    });
  });

  it('should delete a user document', async () => {
    const docId = '123';
    const response = await service.deleteDocument('usuarios', docId);

    expect(response).toBeUndefined(); // Verifica que no haya respuesta, lo cual indica que el documento se eliminó correctamente
  });
});
