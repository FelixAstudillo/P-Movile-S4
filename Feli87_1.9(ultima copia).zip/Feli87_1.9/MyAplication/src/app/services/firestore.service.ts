import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FirestoreService {

  constructor(private firestore: AngularFirestore) {}

  // Método para agregar un documento a una colección
  addDocument(collectionName: string, data: any): Promise<any> {
    // Usamos createId() para generar un ID único para el documento
    const id = this.firestore.createId(); 
    return this.firestore.collection(collectionName).doc(id).set(data)
      .then(() => {
        console.log('Documento agregado con ID:', id);
        return { success: true, id: id }; // Retorna el ID del documento insertado
      })
      .catch(error => {
        console.error('Error al agregar documento:', error);
        throw error; // Lanza el error para manejarlo en el componente
      });
  }

  // Método para obtener todos los documentos de una colección
  getDocuments(collectionName: string): Observable<any[]> {
    return this.firestore.collection(collectionName).valueChanges();
  }

  // Método para obtener un documento por ID
  getDocumentById(collectionName: string, docId: string): Observable<any> {
    return this.firestore.collection(collectionName).doc(docId).valueChanges();
  }

  // Método para eliminar un documento por ID
  deleteDocument(collectionName: string, docId: string): Promise<void> {
    return this.firestore.collection(collectionName).doc(docId).delete()
      .then(() => {
        console.log('Documento eliminado con ID:', docId);
      })
      .catch(error => {
        console.error('Error al eliminar documento:', error);
        throw error; // Lanza el error para manejarlo en el componente
      });
  }

  // Método para actualizar un documento por ID
  updateDocument(collectionName: string, docId: string, data: any): Promise<void> {
    return this.firestore.collection(collectionName).doc(docId).update(data)
      .then(() => {
        console.log('Documento actualizado con ID:', docId);
      })
      .catch(error => {
        console.error('Error al actualizar documento:', error);
        throw error; // Lanza el error para manejarlo en el componente
      });
  }
}
