import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ln',
  templateUrl: './ln.page.html',
  styleUrls: ['./ln.page.scss'],
})
export class LNPage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  ingresarComoAdministrador() {
    this.router.navigate(['/error']); 
  }
}
