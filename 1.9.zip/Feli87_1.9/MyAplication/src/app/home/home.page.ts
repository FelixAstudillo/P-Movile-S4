import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  // Array que contiene los divs dinámicos
  dynamicDivs: { id: number, content: string }[] = [];
  nextId: number = 1; // Para manejar IDs únicos

  constructor() { }

  ngOnInit() {}

  // Función para agregar un nuevo div dinámico
  addNewDiv(): void {
    this.dynamicDivs.unshift({ id: this.nextId++, content: 'Nuevo Div' });
  }

  // Función para editar el contenido de un div
  editDiv(id: number): void {
    const newContent = prompt('Editar contenido:', this.dynamicDivs.find(div => div.id === id)?.content);
    if (newContent !== null) {
      const index = this.dynamicDivs.findIndex(div => div.id === id);
      if (index !== -1) {
        this.dynamicDivs[index].content = newContent;
      }
    }
  }

  // Función para eliminar un div
  deleteDiv(id: number): void {
    this.dynamicDivs = this.dynamicDivs.filter(div => div.id !== id);
  }
}
