import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { updateProfile } from 'firebase/auth';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private afAuth: AngularFireAuth) {}

  // Registro de usuarios
  async register(email: string, password: string): Promise<any> {
    try {
      const userCredential = await this.afAuth.createUserWithEmailAndPassword(email, password);
      return userCredential; // Puedes devolver el userCredential si lo necesitas
    } catch (error) {
      console.error('Error en el registro: ', error);
      throw error; // Lanza el error para que se pueda manejar en el componente
    }
  }

  // Actualizar el nombre del perfil
  async updateProfile(displayName: string): Promise<void> {
    const user = await this.afAuth.currentUser; // Espera a que el usuario esté disponible
    if (user) {
      await updateProfile(user, { displayName });
    } else {
      console.error('No se encontró el usuario');
      throw new Error('No se encontró el usuario');
    }
  }
}
