import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

// https://firebase.google.com/docs/web/setup#available-libraries

const firebaseConfig = {
  apiKey: "AIzaSyCjQwAyHJP0kLmYXONP6U7PVqBS3SukEhw",
  authDomain: "myaplication-3597b.firebaseapp.com",
  projectId: "myaplication-3597b",
  storageBucket: "myaplication-3597b.firebasestorage.app",
  messagingSenderId: "333796973617",
  appId: "1:333796973617:web:b144904804f2922596c910",
  measurementId: "G-KQL30TMC5Q"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);