
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";




export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCjQwAyHJP0kLmYXONP6U7PVqBS3SukEhw",
    authDomain: "myaplication-3597b.firebaseapp.com",
    projectId: "myaplication-3597b",
    storageBucket: "myaplication-3597b.firebasestorage.app",
    messagingSenderId: "333796973617",
    appId: "1:333796973617:web:b144904804f2922596c910",
    measurementId: "G-KQL30TMC5Q"
  }
};
