import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }























  
  // Función para agregar nuevos divs dinámicos al contenedor
  addNewDiv(): void {
    // Seleccionar el contenedor donde se agregarán los divs dinámicos
    const formContainer = document.getElementById('form-container');

    if (formContainer) {
      // Crear un nuevo div
      const newDiv = document.createElement('div');
      newDiv.classList.add('dynamic-div'); // Añadir la clase CSS para los estilos
      newDiv.textContent = 'Nuevo Div'; // El contenido que tendrá el div

      // Insertar el nuevo div en la parte superior del contenedor
      if (formContainer.firstChild) {
        formContainer.insertBefore(newDiv, formContainer.firstChild);
      } else {
        formContainer.appendChild(newDiv);
      }
    }
  }
}
